package com.example.onetap

import java.io.File

/** File operations through `su`, for rooted phones. No Shizuku needed. */
class RootFileService(private val cacheDir: File) : IFileService.Stub() {

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun sh(cmd: String): Pair<Int, String> {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        return p.waitFor() to out.trim()
    }

    private val hasMedia: Boolean by lazy { sh("test -d /data/media/0").first == 0 }

    /** /sdcard and /storage/emulated/0 are mapped to the real folder so root can reach Android/data. */
    private fun real(p: String): String {
        val m = Regex("^(/sdcard|/storage/emulated/0)(/.*)?$").matchEntire(p) ?: return p
        return if (hasMedia) "/data/media/0" + m.groupValues[2] else p
    }

    /** Gives files that root created back to the game's owner so the game can read them. */
    private fun ownerFix(t: String): String {
        val m = Regex("^(.*?/Android/data/[^/]+)(/.*)$").matchEntire(t) ?: return "true"
        val root = m.groupValues[1]
        val sb = StringBuilder("O=\$(stat -c %u:%g ${q(root)}); ")
        var cur = root
        for (part in m.groupValues[2].trim('/').split('/')) {
            cur = "$cur/$part"
            sb.append("[ \"\$(stat -c %u ${q(cur)})\" = 0 ] && chown \$O ${q(cur)}; ")
        }
        sb.append("[ -f ${q(t)} ] && chmod 660 ${q(t)}; restorecon ${q(t)} 2>/dev/null; true")
        return sb.toString()
    }

    override fun destroy() { }

    override fun exists(path: String): Boolean =
        try { sh("test -e ${q(real(path))}").first == 0 } catch (e: Throwable) { false }

    override fun sha1(path: String): String = try {
        val f = q(real(path))
        val (c, o) = sh("[ -f $f ] && sha1sum $f")
        val h = o.substringBefore(' ').trim()
        if (c == 0 && h.length == 40) h else ""
    } catch (e: Throwable) { "" }

    override fun copy(src: String, dst: String): String = try {
        val s = real(src)
        var t = real(dst)
        val isDir = dst.endsWith("/") || sh("test -d ${q(t)}").first == 0
        if (isDir) t = t.trimEnd('/') + "/" + File(src).name
        val parent = File(t).parent ?: "/"
        val (c, o) = sh("mkdir -p ${q(parent)} && cp -rf ${q(s)} ${q(t)} && ( ${ownerFix(t)} )")
        if (c == 0) "OK" else "ERROR: $o"
    } catch (e: Throwable) { "ERROR: ${e.message}" }

    override fun move(src: String, dst: String): String = try {
        val (c, o) = sh("mv -f ${q(real(src))} ${q(real(dst))}")
        if (c == 0) "OK" else "ERROR: $o"
    } catch (e: Throwable) { "ERROR: ${e.message}" }

    override fun delete(path: String): String = try {
        val (c, o) = sh("rm -rf ${q(real(path))}")
        if (c == 0) "OK" else "ERROR: $o"
    } catch (e: Throwable) { "ERROR: ${e.message}" }

    override fun zip(src: String, zipPath: String): String = "ERROR: not supported in root mode"

    override fun unzip(zipPath: String, dstDir: String): String = unzipSub(zipPath, "", "", dstDir)

    /** Extracts in the app's own cache first, then copies the result in as root. */
    override fun unzipSub(zipPath: String, sub: String, marker: String, dstDir: String): String {
        val tmp = File(cacheDir, "rx" + System.nanoTime())
        return try {
            val r = FileService().unzipSub(zipPath, sub, marker, tmp.absolutePath)
            if (r != "OK") r else {
                val dst = real(dstDir).trimEnd('/')
                val own = Regex("^(.*?/Android/data/[^/]+)").find(dst)?.groupValues?.get(1)
                val x = q(dst) + "\"/\$f\""
                val fix = if (own == null) "true" else
                    "O=\$(stat -c %u:%g ${q(own)}); cd ${q(tmp.absolutePath)} && " +
                        "find . -mindepth 1 | while IFS= read -r f; do " +
                        "chown \$O $x 2>/dev/null; [ -f $x ] && chmod 660 $x; restorecon $x 2>/dev/null; " +
                        "done; true"
                val (c, o) = sh(
                    "mkdir -p ${q(dst)} && cp -rf ${q(tmp.absolutePath)}/. ${q(dst)}/ && ( $fix )"
                )
                if (c == 0) "OK" else "ERROR: $o"
            }
        } catch (e: Throwable) {
            "ERROR: ${e.message}"
        } finally {
            tmp.deleteRecursively()
        }
    }
}
